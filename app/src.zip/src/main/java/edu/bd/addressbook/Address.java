package edu.bd.addressbook;

public class Address {
    String name = "";
    String email = "";
    String address1 = "";
    String address2 = "";
    String phone = "";
    String phone2="";




    public Address(String name, String email,String address1, String address2, String phone,String phone2 )
    {
        this.name = name;
        this.email = email;
        this.address1 = address1;
        this.address2 = address2;
        this.phone = phone;
        this.phone2=phone2;

    }
}
